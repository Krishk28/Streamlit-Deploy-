[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=15254184)
# SCS3 - Final Assessment
- Use ***this repo*** for your CSC3 assessment!
- Start using this ***from day one!*** (If you work in another repo and then copy/paste, your progress will not be tracked here)
- ***Clone*** this repo using GitHub desktop, so that you can work locally on your laptop
- See instructions in attached PDF - for how to do this
- Creat sub-folders for any practice projects you do
- Make ***frequent commits***, with messages that describe what you have done
- Push your commits regularly to GitHub
